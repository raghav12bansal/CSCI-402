/******************************************************************************/
/* Important Spring 2023 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "globals.h"
#include "errno.h"
#include "types.h"

#include "mm/mm.h"
#include "mm/tlb.h"
#include "mm/mman.h"
#include "mm/page.h"

#include "proc/proc.h"

#include "util/string.h"
#include "util/debug.h"

#include "fs/vnode.h"
#include "fs/vfs.h"
#include "fs/file.h"

#include "vm/vmmap.h"
#include "vm/mmap.h"

// #include "stat.h"

/*
 * This function implements the mmap(2) syscall, but only
 * supports the MAP_SHARED, MAP_PRIVATE, MAP_FIXED, and
 * MAP_ANON flags.
 *
 * Add a mapping to the current process's address space.
 * You need to do some error checking; see the ERRORS section
 * of the manpage for the problems you should anticipate.
 * After error checking most of the work of this function is
 * done by vmmap_map(), but remember to clear the TLB.
 */
int do_mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off,
            void **ret) {
  // NOT_YET_IMPLEMENTED("VM: do_mmap");
  // return -1;

  uint32_t lopage;
  uint32_t npages;
  uint32_t address = (uint32_t)addr;

  if (address == NULL) {
    // KASSERT(!(flags & MAP_FIXED));
    if ((flags & MAP_FIXED)) {
      curthr->kt_errno = EINVAL;
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
      return -EINVAL;
    }
    lopage = 0;
    npages = ADDR_TO_PN(len - 1) + 1;
  } else {
    if (!PAGE_ALIGNED(address)) {
      curthr->kt_errno = EINVAL;
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
      return -EINVAL;
    }
    lopage = ADDR_TO_PN(address);
    npages = ADDR_TO_PN(address + len - 1) - ADDR_TO_PN(address) + 1;

    // part of the desired address space resides out of the valid address space
    // for a user process.
    // if (address < USER_MEM_LOW || (address + len - 1) >= USER_MEM_HIGH) {
    //   curthr->kt_errno = EINVAL;
    //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
    //   return -EINVAL;
    // }
  }
  if (len > (USER_MEM_HIGH - USER_MEM_LOW) || len <= 0) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
    return -EINVAL;
  }
  /* Some of the following error checks are probably never hit. and we may have
   * to comment them out. */

  // The offset argument was not page-aligned
  if (!PAGE_ALIGNED(off)) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
    return -EINVAL;
  }

  // The len argument was negative or zero.
  // if (len <= 0) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }

  // flags does not include either MAP_PRIVATE or MAP_SHARED.
  if (!((flags & MAP_PRIVATE) || (flags & MAP_SHARED))) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
    return -EINVAL;
  }

  // flags contains both MAP_PRIVATE & MAP_SHARED
  // if ((flags & MAP_PRIVATE) && (flags & MAP_SHARED)) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }

  // MAP_FIXED was specified and the addr argument was not page aligned
  // if ((flags & MAP_FIXED) && !PAGE_ALIGNED(address)) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }

  // flags includes bits that are not part of any valid flags value.
  // if (flags & ~(MAP_PRIVATE | MAP_SHARED | MAP_FIXED | MAP_ANON)) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }

  if (flags & MAP_ANON) {
    // ANON was set, so we are not mapping from a file.
    int return_val = vmmap_map(curproc->p_vmmap, NULL, lopage, npages, prot,
                               flags, off, VMMAP_DIR_HILO, (vmarea_t **)ret);
    if (return_val < 0) {
      // Although there are certain edge cases, we assume that the failure can
      // only be caused by being out of memory.
      curthr->kt_errno = ENOMEM;
      dbg(DBG_PRINT, "(GRADING3D 2)\n");
      return -EINVAL;
    }
    dbg(DBG_PRINT, "(GRADING3D 2)\n");

  } else {
    // If the ANON flag is not set, then we are mapping from a file. In this
    // case we need to do all the error checking to verify the file descriptor
    // is valid and is aligned with the protections and the flags specified.

    // fd should be a valid file descriptor.

    if (fd < 0 || fd >= NFILES) {
      curthr->kt_errno = EBADF;
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
      return -EINVAL;
    }

    file_t *file = fget(fd);  // ref count incremented if file != NULL
    if (file == NULL) {
      curthr->kt_errno = EBADF;
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
      return -EINVAL;
    }

    // fd does not point to a regular file
    // if (!S_ISREG(file->f_vnode->vn_mode)) {
    //   fput(fd);
    //   curthr->kt_errno = EACCES;
    //   return -1;
    // }

    //  fd was not open for reading.
    // if (!(file->f_mode & FMODE_READ)) {
    //   fput(file);
    //   curthr->kt_errno = EACCES;
    //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
    //   return -EINVAL;
    // }

    // The flags MAP_SHARED and PROT_WRITE were specified as part of the flags
    // and prot argument and fd was not open for writing.
    if ((flags & MAP_SHARED) && (prot & PROT_WRITE) &&
        !(file->f_mode & FMODE_WRITE)) {
      fput(file);
      curthr->kt_errno = EACCES;
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
      return -EINVAL;
    }

    // PROT_WRITE is set but file is opened in append only
    // if ((prot & PROT_WRITE) && (file->f_mode == FMODE_APPEND)) {
    //   fput(file);
    //   curthr->kt_errno = EACCES;
    //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
    //   return -EINVAL;
    // }

    int return_val =
        vmmap_map(curproc->p_vmmap, file->f_vnode, lopage, npages, prot, flags,
                  off, VMMAP_DIR_HILO, (vmarea_t **)ret);
    // if (return_val < 0) {
    //   // Although there are certain edge cases, we assume that the failure
    //   can
    //   // only be caused by being out of memory.
    //   fput(file);
    //   curthr->kt_errno = ENOMEM;
    //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
    //   return -EINVAL;
    // }
    fput(file);

    // TODO (shufflerAbhi): Verify if we need to decrement the ref count in
    // this function. This depends on whether the file's mmap operation
    // invoked from vmmap_map increases the ref count.

    // Uncomment the following line if vnode's map does not increment the file
    // ref count
    // fput(fd);
  }

  vmarea_t *mapped_vma = (vmarea_t *)(*ret);
  uintptr_t start_addr = (uintptr_t)PN_TO_ADDR(mapped_vma->vma_start);
  // tlb_flush_range(start_addr, len);
  tlb_flush_all();

  // We need to return the user space virtual address back from mmap. If we
  // don't do this, ret will contain the kernel virtual address
  *ret = (void *)start_addr;
  KASSERT(NULL != curproc->p_pagedir);
  dbg(DBG_PRINT, "(GRADING3A 2.a)\n");
  return 0;
}

/*
 * This function implements the munmap(2) syscall.
 *
 * As with do_mmap() it should perform the required error checking,
 * before calling upon vmmap_remove() to do most of the work.
 * Remember to clear the TLB.
 */
int do_munmap(void *addr, size_t len) {
  // NOT_YET_IMPLEMENTED("VM: do_munmap");
  // return -1;

  // KASSERT(addr != NULL);
  if (USER_MEM_LOW > (unsigned int)addr) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
    return -EINVAL;
  }

  if (USER_MEM_HIGH < ((unsigned int)addr + len)) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 5)\n");
    return -EINVAL;
  }
  if (len > (USER_MEM_HIGH - USER_MEM_LOW) || len <= 0) {
    curthr->kt_errno = EINVAL;
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
    return -EINVAL;
  }
  // if (addr == NULL) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }
  uint32_t address = (uint32_t)addr;

  // The addr argument was not page-aligned
  // if (!PAGE_ALIGNED(address)) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }

  // // As per man page, len need not be a multiple of page size, but our
  // // vmmap_remove only works at a page level, so placing this assert here.
  // KASSERT(PAGE_ALIGNED(len));

  uint32_t npages = ADDR_TO_PN(address + len - 1) - ADDR_TO_PN(address) + 1;
  int return_val = vmmap_remove(curproc->p_vmmap, ADDR_TO_PN(address), npages);

  // KASSERT(return_val == 0);  // We don't expect remove to fail
  // if (return_val < 0) {
  //   curthr->kt_errno = EINVAL;
  //   dbg(DBG_PRINT, "(GRADING3D 1)\n");
  //   return -EINVAL;
  // }
  tlb_flush_all();
  dbg(DBG_PRINT, "(GRADING3D 1)\n");
  return 0;
}
