/******************************************************************************/
/* Important Spring 2023 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "types.h"
#include "globals.h"
#include "errno.h"

#include "util/debug.h"
#include "util/string.h"

#include "proc/proc.h"
#include "proc/kthread.h"

#include "mm/mm.h"
#include "mm/mman.h"
#include "mm/page.h"
#include "mm/pframe.h"
#include "mm/mmobj.h"
#include "mm/pagetable.h"
#include "mm/tlb.h"

#include "fs/file.h"
#include "fs/vnode.h"

#include "vm/shadow.h"
#include "vm/vmmap.h"

#include "api/exec.h"

#include "main/interrupt.h"

/* Pushes the appropriate things onto the kernel stack of a newly forked thread
 * so that it can begin execution in userland_entry.
 * regs: registers the new thread should have on execution
 * kstack: location of the new thread's kernel stack
 * Returns the new stack pointer on success. */
static uint32_t fork_setup_stack(const regs_t *regs, void *kstack) {
  /* Pointer argument and dummy return address, and userland dummy return
   * address */
  uint32_t esp =
      ((uint32_t)kstack) + DEFAULT_STACK_SIZE - (sizeof(regs_t) + 12);
  *(void **)(esp + 4) = (void *)(esp + 8); /* Set the argument to point to
                                              location of struct on stack */
  memcpy((void *)(esp + 8), regs, sizeof(regs_t)); /* Copy over struct */
  return esp;
}

/*
 * The implementation of fork(2). Once this works,
 * you're practically home free. This is what the
 * entirety of Weenix has been leading up to.
 * Go forth and conquer.
 */
int do_fork(struct regs *regs) {
  KASSERT(regs != NULL);
  KASSERT(curproc != NULL);
  KASSERT(curproc->p_state == PROC_RUNNING);
  dbg(DBG_PRINT, "(GRADING3A 7.a)\n");

  vmarea_t *vma, *clone_vma;
  pframe_t *pf;
  mmobj_t *to_delete, *new_shadowed;
  proc_t *fork_process = proc_create("fork process");
  fork_process->p_vmmap = vmmap_clone(curproc->p_vmmap);
  fork_process->p_vmmap->vmm_proc = fork_process;
  fork_process->p_brk = curproc->p_brk;
  fork_process->p_start_brk = curproc->p_start_brk;

  // The mmobj for the fork process is NULL so what about the refence count
  vmarea_t *child_vmarea;
  list_iterate_begin(&fork_process->p_vmmap->vmm_list, child_vmarea, vmarea_t,
                     vma_plink) {
    vmarea_t *parent_vmarea =
        vmmap_lookup(curproc->p_vmmap, child_vmarea->vma_start);
    if ((child_vmarea->vma_flags & MAP_PRIVATE) == MAP_PRIVATE) {
      // The vmarea is a private mapping so we need to link shadow objects
      parent_vmarea->vma_obj->mmo_ops->ref(parent_vmarea->vma_obj);

      mmobj_t *parent_shandow_obj = shadow_create();
      parent_shandow_obj->mmo_shadowed = parent_vmarea->vma_obj;
      parent_shandow_obj->mmo_un.mmo_bottom_obj =
          parent_vmarea->vma_obj->mmo_un.mmo_bottom_obj;

      mmobj_t *child_shandow_obj = shadow_create();
      child_shandow_obj->mmo_shadowed = parent_vmarea->vma_obj;
      child_shandow_obj->mmo_un.mmo_bottom_obj =
          parent_vmarea->vma_obj->mmo_un.mmo_bottom_obj;

      parent_vmarea->vma_obj = parent_shandow_obj;
      child_vmarea->vma_obj = child_shandow_obj;

      parent_shandow_obj->mmo_un.mmo_bottom_obj->mmo_ops->ref(
          parent_shandow_obj->mmo_un.mmo_bottom_obj);
      child_shandow_obj->mmo_un.mmo_bottom_obj->mmo_ops->ref(
          child_shandow_obj->mmo_un.mmo_bottom_obj);

      dbg(DBG_PRINT, "(GRADING3D 1)\n");
    } else {
      child_vmarea->vma_obj = parent_vmarea->vma_obj;
      // Basically same as the above code itself
      // TOOD ref count of bottom object
      child_vmarea->vma_obj->mmo_ops->ref(child_vmarea->vma_obj);
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
    }
    list_insert_tail(mmobj_bottom_vmas(parent_vmarea->vma_obj),
                     &child_vmarea->vma_olink);
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
  }
  list_iterate_end();

  kthread_t *fork_thread = kthread_clone(curthr);
  fork_thread->kt_proc = fork_process;

  fork_process->p_pagedir = pt_create_pagedir();
  KASSERT(fork_process->p_state == PROC_RUNNING);
  KASSERT(fork_process->p_pagedir != NULL);
  KASSERT(fork_thread->kt_kstack != NULL);
  dbg(DBG_PRINT, "(GRADING3A 7.a)\n");

  fork_thread->kt_ctx.c_pdptr = (pagedir_t *)fork_process->p_pagedir;
  fork_thread->kt_ctx.c_eip = (uintptr_t)userland_entry;
  // Return value of child has to be zero
  regs->r_eax = 0;

  uint32_t return_val = fork_setup_stack(regs, fork_thread->kt_kstack);
  fork_thread->kt_ctx.c_esp = return_val;
  fork_thread->kt_ctx.c_kstack = (uintptr_t)fork_thread->kt_kstack;
  fork_thread->kt_ctx.c_kstacksz = DEFAULT_STACK_SIZE;

  list_insert_head(&fork_process->p_threads, &fork_thread->kt_plink);

  for (int i = 0; i < NFILES; i++) {
    fork_process->p_files[i] = curproc->p_files[i];
    if (fork_process->p_files[i] != NULL) {
      fref(curproc->p_files[i]);
      dbg(DBG_PRINT, "(GRADING3D 1)\n");
    }
    dbg(DBG_PRINT, "(GRADING3D 1)\n");
  }
  // TODO I am not doing this as it have been done in proc_create()
  //   fork_process->p_cwd = curproc->p_cwd;
  //   if (curproc->p_cwd != NULL) {
  //     vref(curproc->p_cwd);
  //   }
  regs->r_eax = fork_process->p_pid;
  // Not doing unmap for child as for the table is new
  pt_unmap_range(fork_process->p_pagedir, USER_MEM_LOW, USER_MEM_HIGH);
  pt_unmap_range(curproc->p_pagedir, USER_MEM_LOW, USER_MEM_HIGH);
  tlb_flush_all();
  sched_make_runnable(fork_thread);
  //   NOT_YET_IMPLEMENTED("VM: do_fork");
  dbg(DBG_PRINT, "(GRADING3D 1)\n");
  return fork_process->p_pid;
}
